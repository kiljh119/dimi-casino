// 모듈화된 애플리케이션으로 리디렉션
require('./src/app');